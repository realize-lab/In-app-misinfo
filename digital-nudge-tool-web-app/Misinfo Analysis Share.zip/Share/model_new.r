library(tidyverse)
library(stringr)
library(broom)
library(lme4)
library(afex)
library(texreg)
library(rstatix)
library(lmerTest)
# library(dypler)


column <- list('Intervention_ID', "Tag", 'Misinfo', "Misinfo_Answer", 'Trust', "Child", "BreastCancer" , 'Correct' , "Correct+Unsure" , "Adherence" , "Adherence+Unsure ", "Unsure", 'Participant_ID')

for (i in 0:0){

    file_name <- "revised_table.csv"
    print(file_name)
    clean <- read.csv(file_name,stringsAsFactors = FALSE)


    clean$Intervention_ID<-as.factor(clean$Intervention_ID)
    clean$Trust<-as.factor(clean$Trust)
    clean$Misinfo<-as.factor(clean$Misinfo)
    clean$Misinfo_Answer<-as.factor(clean$Misinfo_Answer)
    clean$Tag<-as.factor(clean$Tag)
    clean$Participant_ID<-as.factor(clean$Participant_ID)
    # clean$Misinfo_Answer<-as.factor(clean$Misinfo_Answer)

    # view(clean)
    df_filtered <- df_filtered
    # df_filtered <- clean %>% filter(Misinfo_Answer=="False")

    # view(df_filtered)



    # Correct, CorrectUnsure, Unsure, 
        glmm_baseline <-  glmer(Correct ~ Intervention_ID + (1| Participant_ID) + (1| Tag), 
                            data = df_filtered, 
                            family = binomial)

# lm_baseline <-  lmer(Outcome ~ Misinfo + (1| Participant_ID) + (1| Tag),
#             data = clean)

    summary_lme <- summary(glmm_baseline)

    print(summary_lme)
    print(summary_lme$coefficients)
    estimates <- summary_lme$coefficients[2:5]
    std <- summary_lme$coefficients[7:10]
    # print(estimates)
    print("odds")
    print(exp(estimates))
    # print("std")
    # print(std)


    for (i in 1:length(estimates)) {
        p <- estimates[[i]]
        s <- std[[i]]
        exp_e <- exp(p)
        odds_ratios <- exp(rnorm(1000, mean=p, sd=s))
        lb <- quantile(odds_ratios, 0.025)
        ub <- quantile(odds_ratios, 0.975)
        print(exp_e)
        print(lb)
        print(ub)
    }
}